const BASE_URL = "https://chromeai.googleapis.com/v1";
const API_KEY = "AIzaSyByQm4L3Hz9MA2GZtxRt7D3H7RfgqnoCVg"; // Replace with your actual API key

// Function to detect language
export const detectLanguage = async (text) => {
    try {
        const response = await fetch(`${BASE_URL}/language-detection:predict?key=${API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ text }),
        });

        const data = await response.json();
        if (data.language) {
            return data.language;
        } else {
            throw new Error("Invalid response structure.");
        }
    } catch (error) {
        console.error("Language detection failed:", error);
        return null;
    }
};

// Function to summarize text
export const summarizeText = async (text) => {
    try {
        const response = await fetch(`${BASE_URL}/summarizer:predict?key=${API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ text }),
        });

        const data = await response.json();
        if (data.summary) {
            return data.summary;
        } else {
            throw new Error("Invalid response structure.");
        }
    } catch (error) {
        console.error("Summarization failed:", error);
        return null;
    }
};

// Function to translate text
export const translateText = async (text, targetLanguage) => {
    try {
        const response = await fetch(`${BASE_URL}/translator:predict?key=${API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ text, target_language: targetLanguage }),
        });

        const data = await response.json();
        if (data.translation) {
            return data.translation;
        } else {
            throw new Error("Invalid response structure.");
        }
    } catch (error) {
        console.error("Translation failed:", error);
        return null;
    }
};
