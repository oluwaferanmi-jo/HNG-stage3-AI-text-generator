const LANGUAGE_API_TOKEN = import.meta.env.VITE_GOOGLE_LANG_TOKEN;
const TRANSLATION_API_TOKEN = import.meta.env.VITE_GOOGLE_TRANS_TOKEN;
const SUMMARIZER_API_TOKEN = import.meta.env.VITE_GOOGLE_SUMM_TOKEN;

import { detectLanguageLocally, translateTextLocally, localSummarizeText } from '../LocalLanguageUtils';

export async function detectLanguage(text) {
  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/language-detection:detect",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${LANGUAGE_API_TOKEN}`,
        },
        body: JSON.stringify({ text }),
      }
    );

    const data = await response.json();
    console.log("Language Detection API Response:", data);

    if (data.language) {
      return data.language;
    }
    throw new Error("Invalid API response, falling back to local.");
  } catch (error) {
    console.error("Google Language Detection API failed:", error);
    return detectLanguageLocally(text);
  }
}

export async function translateText(text, targetLanguage) {
  try {
    const response = await fetch(
      `https://translation.googleapis.com/language/translate/v2?key=${TRANSLATION_API_TOKEN}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          q: text,
          target: targetLanguage,
        }),
      }
    );

    const data = await response.json();
    console.log("Translation API Response:", data);

    if (data.data && data.data.translations.length > 0) {
      return data.data.translations[0].translatedText;
    }
    throw new Error("Invalid API response, falling back to local.");
  } catch (error) {
    console.error("Google Translation API failed:", error);
    
    // Step 2: Try local dictionary first
    let localTranslation = await translateTextLocally(text, targetLanguage);
    if (!localTranslation.includes("Translation unavailable")) return localTranslation;

    return `Translation unavailable for "${text}"`;
  }
}

export async function summarizeText(text) {
  if (text.split(" ").length <= 150) return text;

  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/text-summarization:summarize",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUMMARIZER_API_TOKEN}`,
        },
        body: JSON.stringify({ text }),
      }
    );

    const data = await response.json();
    console.log("Summarization API Response:", data);

    if (data.summary) {
      return data.summary;
    }
    throw new Error("Invalid API response, falling back to local.");
  } catch (error) {
    console.error("Google Summarization API failed:", error);
    return localSummarizeText(text);
  }
}
