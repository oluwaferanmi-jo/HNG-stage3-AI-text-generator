const SUMMARIZER_API_TOKEN = import.meta.env.VITE_GOOGLE_SUMM_TOKEN;

export async function summarizeText(text) {
  if (text.split(" ").length <= 150) return text; // Return as-is if text is short

  try {
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/text-summarization:summarize", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUMMARIZER_API_TOKEN}`
      },
      body: JSON.stringify({ text }) 
    });

    const data = await response.json();
    
    if (data.summary) {
      return data.summary;
    } else {
      console.warn("Summarization API returned no summary. Falling back.");
      return localSummarizeText(text); // Fallback function
    }
  } catch (error) {
    console.error("Google Summarization API failed. Using local fallback.");
    return localSummarizeText(text);
  }
}

// Local fallback summarization (Modify this if needed)
function localSummarizeText(text) {
  const sentences = text.split(".");
  return sentences.slice(0, Math.ceil(sentences.length / 2)).join(".") + "."; 
}
