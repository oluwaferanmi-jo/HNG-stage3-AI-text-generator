import axios from 'axios';

export function detectLanguageLocally(text) {
  const patterns = {
    en: /\b(the|and|you|is|this)\b/i,
    es: /\b(el|la|de|y|que)\b/i,
    fr: /\b(le|la|de|et|que)\b/i,
    pt: /\b(o|a|de|e|que)\b/i,
  };

  for (const [lang, regex] of Object.entries(patterns)) {
    if (regex.test(text)) return lang;
  }

  return "unknown"; // Default if no match
}

export async function translateTextLocally(text, targetLanguage) {
  console.log("Local translation attempt:", text, "to", targetLanguage);

  // Expanded dictionary with more words
  const translations = {
    hello: { es: "hola", fr: "bonjour", pt: "olá", de: "hallo" },
    goodbye: { es: "adiós", fr: "au revoir", pt: "adeus", de: "auf wiedersehen" },
    thanks: { es: "gracias", fr: "merci", pt: "obrigado", de: "danke" },
    yes: { es: "sí", fr: "oui", pt: "sim", de: "ja" },
    no: { es: "no", fr: "non", pt: "não", de: "nein" },
  };

  if (translations[text.toLowerCase()]?.[targetLanguage]) {
    return translations[text.toLowerCase()][targetLanguage];
  }

  // If word is not in the local dictionary, use fallback API
  try {
    const response = await axios.post(
      'https://libretranslate.com/translate',
      {
        q: text,
        source: "auto",
        target: targetLanguage,
        format: "text",
      },
      { headers: { "Content-Type": "application/json" } }
    );

    return response.data.translatedText;
  } catch (error) {
    console.error("Fallback translation API failed:", error);
    return `Translation unavailable for "${text}"`;
  }
}

export function localSummarizeText(text) {
  const words = text.split(" ");
  if (words.length <= 150) return text; // No need to summarize short text
  return words.slice(0, 150).join(" ") + "..."; // Simple truncation-based summarization
}
