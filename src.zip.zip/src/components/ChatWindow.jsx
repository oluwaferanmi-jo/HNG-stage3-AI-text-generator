import React, { useState } from "react";
import { detectLanguage, summarizeText, translateText } from "../api/APIHandler";
import TextInput from "./TextInput";
import MessageBubble from "./MessageBubble"; // Ensure this is imported

const ChatWindow = () => {
    const [messages, setMessages] = useState([]); // Store chat messages
    const [selectedLanguage, setSelectedLanguage] = useState("en"); // Default language

    // Function to handle text submission
    const handleSendMessage = async (text) => { 
        if (!text.trim()) return; 

        const userMessage = { text, sender: "user" };
        setMessages((prev) => [...prev, userMessage]); 

        // Detect language
        const detectedLanguage = await detectLanguage(text);
        const newMessage = {
            text,
            sender: "bot",
            language: detectedLanguage,
            showSummarize: detectedLanguage === "en" && text.length > 150, 
        };

        setMessages((prev) => [...prev, newMessage]);
    };

    // Function to summarize text
    const handleSummarize = async (text, index) => {
        const summary = await summarizeText(text);
        if (summary) {
            setMessages((prev) =>
                prev.map((msg, i) => (i === index ? { ...msg, summary } : msg))
            );
        }
    };

    // Function to translate text
    const handleTranslate = async (text, index) => {
        const translation = await translateText(text, selectedLanguage);
        if (translation) {
            setMessages((prev) =>
                prev.map((msg, i) => (i === index ? { ...msg, translation } : msg))
            );
        }
    };

    return (
        <div className="Chat">
            {/* Chat Messages */}
            <div className="Messages">
                {messages.map((msg, index) => (
                    <div key={index} className="MessageContainer">
                        <MessageBubble text={msg.text} sender={msg.sender} />

                        {msg.language && <p className="Language">Detected Language: {msg.language}</p>}

                        {/* Summarize Button */}
                        {msg.showSummarize && (
                            <button className="SummarizeButton" onClick={() => handleSummarize(msg.text, index)}>
                                Summarize
                            </button>
                        )}

                        {/* Translate Section */}
                        <div className="TranslateSection">
                            <select
                                value={selectedLanguage}
                                onChange={(e) => setSelectedLanguage(e.target.value)}
                            >
                                <option value="en">English</option>
                                <option value="pt">Portuguese</option>
                                <option value="es">Spanish</option>
                                <option value="ru">Russian</option>
                                <option value="tr">Turkish</option>
                                <option value="fr">French</option>
                            </select>
                            <button className="TranslateButton" onClick={() => handleTranslate(msg.text, index)}>
                                Translate
                            </button>
                        </div>

                        {/* Display Summarized or Translated Output */}
                        {msg.summary && <p className="Summary">Summary: {msg.summary}</p>}
                        {msg.translation && <p className="Translation">Translation: {msg.translation}</p>}
                    </div>
                ))}
            </div>

            {/* Text Input */}
            <TextInput onSend={handleSendMessage} />
        </div>
    );
};

export default ChatWindow;
